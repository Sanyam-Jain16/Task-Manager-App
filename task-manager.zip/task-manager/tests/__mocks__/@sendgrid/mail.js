module.exports = {
    setApiKey() {

    },
    send() {
        
    }
}